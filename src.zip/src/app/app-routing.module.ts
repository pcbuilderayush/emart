import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
// import {ActivatedRoute,Router} from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ClothingComponent } from './clothing/clothing.component';
import { HeaderComponent } from './header/header.component';

const routes: Routes = [
  {path:'home',component:HomeComponent},
  {path:'clothing',component:ClothingComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
